<?php
/**
 * Copyright (c) 2008 Massachusetts Institute of Technology
 * 
 * Licensed under the MIT License
 * Redistributions of files must retain the above copyright notice.
 * 
 */


$header = "Useful Links";
$module = "links";

$help = array(
  'Get quick access to mobile-optimized websites of organizations providing affiliated services to the MIT community.',
);

require "../page_builder/help.php";

?>
