<?php
/**
 * Copyright (c) 2008 Massachusetts Institute of Technology
 * 
 * Licensed under the MIT License
 * Redistributions of files must retain the above copyright notice.
 * 
 */


$header = "3DOWN";
$module = "3down";

$help = array(
    'Get the latest status updates on many of MIT&apos;s essential tech services, including phone, email, web, network services, and more.',
);

require "../page_builder/help.php";

?>
